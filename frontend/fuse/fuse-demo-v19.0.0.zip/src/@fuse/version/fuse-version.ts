import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('19.0.0').full;
